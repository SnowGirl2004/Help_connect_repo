const express = require("express");
const router = express.Router();
const Provider = require("../models/Provider");

// GET /api/providers  -> list providers (with optional query params ?q=&category=&location=&sort=)
router.get("/", async (req, res) => {
  try {
    const { q, category, location, sort } = req.query;
    let filter = {};
    if (category) filter.category = category;
    if (location) filter.location = location;
    if (q) {
      const re = new RegExp(q, "i");
      filter.$or = [{ name: re }, { skills: re }, { category: re }];
    }
    let query = Provider.find(filter);
    if (sort === "rating_desc") query = query.sort({ rating: -1 });
    if (sort === "price_asc") query = query.sort({ price: 1 });
    if (sort === "price_desc") query = query.sort({ price: -1 });
    if (sort === "exp_desc") query = query.sort({ exp: -1 });
    const list = await query.exec();
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/providers/:id
router.get("/:id", async (req, res) => {
  try {
    const p = await Provider.findOne({ id: Number(req.params.id) });
    if (!p) return res.status(404).json({ error: "Provider not found" });
    res.json(p);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/providers -> create a provider (used after application accepted)
router.post("/", async (req, res) => {
  try {
    // Expect JSON body with provider fields: id, name, emoji, category, location, price, exp, rating, jobs, skills, phone
    const body = req.body;
    if (!body || !body.name) return res.status(400).json({ error: "name required" });

    // Ensure unique id - if not provided, generate one
    if (!body.id) {
      const last = await Provider.findOne().sort({ id: -1 }).exec();
      body.id = last ? (last.id + 1) : 1;
    }

    // Convert skills string -> array if necessary
    if (body.skills && typeof body.skills === "string") {
      body.skills = body.skills.split(",").map(s => s.trim()).filter(Boolean);
    }

    const p = new Provider(body);
    await p.save();
    res.status(201).json({ ok: true, provider: p });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
