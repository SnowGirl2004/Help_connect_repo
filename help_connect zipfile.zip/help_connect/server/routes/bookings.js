const express = require("express");
const router = express.Router();
const Booking = require("../models/Booking");

// POST /api/bookings  -> create booking
router.post("/", async (req, res) => {
  try {
    const data = req.body;
    const b = new Booking(data);
    await b.save();
    res.status(201).json({ ok: true, booking: b });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET /api/bookings  -> list (admin/dev)
router.get("/", async (req, res) => {
  try {
    const list = await Booking.find().sort({ createdAt: -1 }).limit(200);
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;