const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();
const Application = require("../models/Application");

// multer storage (dev)
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, "..", "uploads"));
  },
  filename: function (req, file, cb) {
    const name = Date.now() + "-" + file.originalname.replace(/\s+/g, "_");
    cb(null, name);
  }
});
const upload = multer({ storage });

router.post("/", upload.single("aadhaar"), async (req, res) => {
  try {
    const body = req.body;
    if (req.file) body.aadhaarFile = "/uploads/" + req.file.filename;
    const app = new Application(body);
    await app.save();
    res.status(201).json({ ok: true, application: app });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const list = await Application.find().sort({ createdAt: -1 }).limit(200);
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;