/* app.js - HelpConnect frontend (API-backed)
   Features:
   - Theme switcher
   - Mobile nav toggle
   - Simple hash routing between pages
   - Render services and providers (from /api/providers)
   - Submit booking -> POST /api/bookings
   - Submit application (with Aadhaar) -> POST /api/applications and auto-create provider via POST /api/providers
   - Toast notifications
*/

(() => {
  'use strict';

  /* ----------------- tiny helpers ----------------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const debounce = (fn, ms = 200) => {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  };
  const safeJSON = async (res) => {
    const text = await res.text();
    try { return JSON.parse(text || '{}'); } catch { return { text }; }
  };
  const fmtINR = n => n > 999 ? `₹${(n/1000).toFixed(0)}k/month` : `₹${n}`;

  /* ----------------- toast ----------------- */
  const toastRoot = document.getElementById('toastRoot');
  function showToast(msg, type = 'success') {
    if (!toastRoot) return;
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<div class="toast-icon">${type === 'success' ? '✅' : 'ℹ️'}</div><div>${msg}</div>`;
    toastRoot.appendChild(el);
    // animate out
    setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(20px)'; }, 2800);
    setTimeout(() => { el.remove(); }, 3400);
  }

  /* ----------------- Theme switcher ----------------- */
  function initTheme() {
    const themeBtns = $$('.theme-btn') || [];
    function setTheme(t) {
      document.documentElement.setAttribute('data-theme', t);
      themeBtns.forEach(b => b.classList.toggle('active', b.dataset.theme === t));
      localStorage.setItem('hc_theme', t);
    }
    themeBtns.forEach(b => b.addEventListener('click', () => setTheme(b.dataset.theme)));
    setTheme(localStorage.getItem('hc_theme') || 'light');
  }

  /* ----------------- Mobile nav ----------------- */
  function initMobileNav() {
    const mobileToggle = $('#mobileToggle');
    const navLinks = $('#navLinks');
    if (!mobileToggle || !navLinks) return;
    mobileToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      mobileToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    navLinks.addEventListener('click', (e) => {
      if (e.target.matches('a')) navLinks.classList.remove('open');
    });
  }

  /* ----------------- Routing (hash-based) ----------------- */
  const pages = () => $$('.page');
  const routeMap = {
    home: '#page-home',
    services: '#page-services',
    providers: '#page-providers',
    help: '#page-help',
    register: '#page-register',
    about: '#page-about'
  };
  function setActiveNav(route) {
    $$('#navLinks a').forEach(a => a.setAttribute('aria-current', a.dataset.route === route ? 'page' : 'false'));
  }
  function navigate(hash) {
    const route = (hash.replace('#', '') || 'home');
    pages().forEach(p => p.classList.remove('active'));
    const sel = routeMap[route] || routeMap.home;
    $(sel)?.classList.add('active');
    setActiveNav(route);
    $('#main')?.focus({ preventScroll: true });
  }
  window.addEventListener('hashchange', () => navigate(location.hash));
  // also handle nav links with data-route attributes to change hash
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-route]');
    if (a) {
      // allow default anchor behavior — hash will change and route will run
      // but close mobile nav
      const navLinks = $('#navLinks');
      if (navLinks) navLinks.classList.remove('open');
    }
  });

  /* ----------------- Data: services (static) ----------------- */
  const categories = [
      { id: 'electrician', name: 'Electrician', icon: '💡', desc: 'Wiring, MCB, sockets' },
      { id: 'plumber', name: 'Plumber', icon: '🚰', desc: 'Leak fix, taps, pipes' },
      { id: 'carpenter', name: 'Carpenter', icon: '🪵', desc: 'Furniture, fittings' },
      { id: 'appliance', name: 'Appliance Repair', icon: '🧊', desc: 'AC, fridge, washing' },
      { id: 'painter', name: 'Painter', icon: '🎨', desc: 'Interior & exterior' },
      { id: 'cleaning', name: 'House Cleaning', icon: '🧽', desc: 'Deep clean, bathroom, kitchen' },
      { id: 'tutor', name: 'Home Tutor', icon: '📚', desc: 'Math, Science, Languages' },
      { id: 'it', name: 'IT Support', icon: '🖥️', desc: 'Setup, repair, network' },
      { id: 'caregiver', name: 'Caregiver', icon: '🤗', desc: 'Elderly care, child care' },
      { id: 'chef', name: 'Home Chef', icon: '👨‍🍳', desc: 'Cooking, meal prep' },
      { id: 'security', name: 'Security Guard', icon: '🛡️', desc: 'Night watch, protection' },
      { id: 'driver', name: 'Driver', icon: '🚗', desc: 'Personal, family driver' },
      { id: 'gardener', name: 'Gardener', icon: '🌱', desc: 'Landscaping, plant care' },
      { id: 'pest', name: 'Pest Control', icon: '🐜', desc: 'Cockroach, termite, rats' },
      { id: 'massage', name: 'Massage Therapist', icon: '💆', desc: 'Spa, therapeutic massage' },
      { id: 'beauty', name: 'Beauty Services', icon: '💅', desc: 'Salon at home, grooming' }
  ];

  /* ----------------- Render services UI ----------------- */
  function renderServicePills() {
    const wrap = $('#servicePills');
    if (!wrap) return;
    wrap.innerHTML = '';
    const all = document.createElement('button');
    all.className = 'pill active';
    all.textContent = 'All';
    all.dataset.id = '';
    wrap.appendChild(all);
    categories.forEach(c => {
      const b = document.createElement('button');
      b.className = 'pill';
      b.textContent = `${c.icon} ${c.name}`;
      b.dataset.id = c.id;
      wrap.appendChild(b);
    });
    wrap.addEventListener('click', (e) => {
      if (!e.target.classList.contains('pill')) return;
      $$('#servicePills .pill').forEach(x => x.classList.remove('active'));
      e.target.classList.add('active');
      const id = e.target.dataset.id;
      renderServicesGrid(id);
    });
  }

  function renderServicesGrid(filterId = '') {
    const grid = $('#servicesGrid');
    if (!grid) return;
    grid.innerHTML = '';
    const list = filterId ? categories.filter(c => c.id === filterId) : categories;
    list.forEach(c => {
      const card = document.createElement('div');
      card.className = 'card service-card';
      card.innerHTML = `
        <div class="service-icon">${c.icon}</div>
        <h3>${c.name}</h3>
        <p>${c.desc}</p>
        <div class="actions" style="justify-content:center;margin-top:.6rem;">
          <a class="button secondary" href="#providers" data-route="providers" data-cat="${c.id}">View Providers</a>
          <a class="button" href="#help" data-route="help">Book</a>
        </div>`;
      // clicking card (not link) should go to providers filtered
      card.addEventListener('click', (e) => {
        if (e.target.matches('a')) return;
        location.hash = '#providers';
        setTimeout(() => { $('#provCategory').value = c.id; applyProvFilters(); }, 0);
      });
      grid.appendChild(card);
    });
  }

  function renderHomeCategories() {
    const home = $('#homeCategories');
    if (!home) return;
    home.innerHTML = '';
    categories.slice(0, 8).forEach(c => {
      const card = document.createElement('div');
      card.className = 'card service-card';
      card.tabIndex = 0;
      card.innerHTML = `
        <div class="service-icon">${c.icon}</div>
        <h3>${c.name}</h3>
        <p>${c.desc}</p>
        <div class="actions" style="justify-content:center;margin-top:.6rem;">
          <a class="button secondary" href="#providers" data-route="providers" data-cat="${c.id}">View Providers</a>
          <a class="button" href="#help" data-route="help">Book</a>
        </div>`;
      card.addEventListener('click', (e) => {
        if (e.target.matches('a')) return;
        location.hash = '#providers';
        setTimeout(() => { $('#provCategory').value = c.id; applyProvFilters(); }, 0);
      });
      home.appendChild(card);
    });
  }

  /* ----------------- Providers: fetch & render ----------------- */
  async function fetchProviders(params = {}) {
    try {
      const qs = new URLSearchParams(params).toString();
      const url = `/api/providers${qs ? `?${qs}` : ''}`;
      const res = await fetch(url);
      if (!res.ok) {
        const body = await safeJSON(res);
        throw new Error(body.error || (`Failed to fetch providers (status ${res.status})`));
      }
      return await res.json();
    } catch (err) {
      console.error('fetchProviders error', err);
      showToast('Failed to load providers', 'error');
      return [];
    }
  }

  function starRow(rating) {
    const full = Math.floor(rating || 0);
    const half = (rating || 0) - full >= 0.5;
    let stars = '★★★★★'.slice(0, full);
    if (half && stars.length < 5) stars += '⭐';
    return stars.padEnd(5, '☆');
  }

  function providerCardDOM(p) {
    const el = document.createElement('div');
    el.className = 'card provider-card';
    el.innerHTML = `
      <div class="provider-header">
        <div class="avatar" aria-hidden="true">${p.emoji || '👤'}</div>
        <div style="font-weight:800;font-size:1.1rem;">${p.name}</div>
        <div class="chip">${p.category || ''}</div>
      </div>
      <div class="provider-body">
        <div class="provider-skills">${(p.skills || []).map(s => `<span class="skill-tag">${s}</span>`).join('')}</div>
        <div class="provider-info">
          <div>📍 ${p.location || ''}</div>
          <div>⭐ ${p.rating || '0'} • ${starRow(p.rating || 0)} • ${p.jobs || 0} jobs</div>
          <div>💼 ${p.exp || 0} yrs exp • 💸 ${fmtINR(p.price || 0)} ${p.price > 999 ? '' : 'visit'}</div>
        </div>
        <div class="provider-actions">
          <button class="button" data-action="book" data-id="${p.id}">📅 Book</button>
          <a class="button secondary" href="${p.phone || '#'}" data-action="call">📞 Call</a>
          <button class="button secondary" data-action="details" data-id="${p.id}">ℹ️ Details</button>
        </div>
      </div>`;
    return el;
  }

  async function renderProvidersGrid() {
    const grid = $('#providersGrid');
    if (!grid) return;
    grid.innerHTML = `<div class="card" style="padding:1rem;">Loading providers...</div>`;
    const params = {
      q: $('#provSearch')?.value?.trim() || '',
      category: $('#provCategory')?.value || '',
      location: $('#provLocation')?.value || '',
      sort: $('#provSort')?.value || 'rating_desc'
    };
    const list = await fetchProviders(params);
    grid.innerHTML = '';
    if (!list.length) {
      grid.innerHTML = `<div class="card" style="padding:1rem;">No providers found. Try adjusting filters.</div>`;
      return;
    }
    list.forEach(p => grid.appendChild(providerCardDOM(p)));
  }

  /* ----------------- Provider filters initialization ----------------- */
  function initProviderFilters() {
    const selCat = $('#provCategory');
    const selLoc = $('#provLocation');
    if (selCat) {
      selCat.innerHTML = '<option value="">All Categories</option>' + categories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    }
    // Locations are loaded dynamically from backend when rendering providers first time
    // But initialize empty until load
    if (selLoc) selLoc.innerHTML = '<option value="">All Locations</option>';
  }

  async function populateLocationsFromProviders() {
    try {
      const list = await fetchProviders({});
      const uniqueLoc = [...new Set(list.map(p => p.location).filter(Boolean))].sort();
      const sel = $('#provLocation');
      if (sel) sel.innerHTML = '<option value="">All Locations</option>' + uniqueLoc.map(l => `<option>${l}</option>`).join('');
    } catch (err) {
      // ignore
    }
  }

  function applyProvFilters() {
    renderProvidersGrid();
  }

  /* ----------------- Booking modal & submit ----------------- */
  const bookingModal = $('#bookingModal');
  const bookingForm = $('#bookingForm');

  function openBookingModal(p) {
    if (!bookingModal) return;
    $('#bookingProviderId').value = p.id;
    $('#bookingProvider').value = p.name;
    $('#bookingService').value = (categories.find(c => c.id === p.category)?.name || p.category || '');
    bookingModal.classList.add('active');
    bookingModal.setAttribute('aria-hidden', 'false');
    $('#bookingName').focus();
  }
  function closeBookingModal() {
    if (!bookingModal) return;
    bookingModal.classList.remove('active');
    bookingModal.setAttribute('aria-hidden', 'true');
    bookingForm?.reset();
  }

  async function submitBooking(form) {
    try {
      // basic validation
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      const payload = {
        providerId: $('#bookingProviderId')?.value,
        providerName: $('#bookingProvider')?.value,
        service: $('#bookingService')?.value,
        name: $('#bookingName')?.value,
        phone: $('#bookingPhone')?.value,
        date: $('#bookingDate')?.value,
        time: $('#bookingTime')?.value,
        address: $('#bookingAddress')?.value
      };
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const body = await safeJSON(res);
      if (!res.ok) {
        throw new Error(body.error || 'Booking failed');
      }
      showToast('Booking confirmed — we will connect you', 'success');
      closeBookingModal();
    } catch (err) {
      console.error(err);
      showToast(err.message || 'Booking failed', 'error');
    }
  }

  /* ----------------- Application (register) submit: send multipart + create provider ----------------- */
  async function submitApplicationAndAddProvider(form) {
    try {
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      // Build FormData for application
      const fd = new FormData(form);

      // POST application
      const appRes = await fetch('/api/applications', { method: 'POST', body: fd });
      const appBody = await safeJSON(appRes);
      if (!appRes.ok) throw new Error(appBody.error || 'Application failed');

      // Build provider object to create immediately (minimal)
      const providerObj = {
        name: $('#regName')?.value || fd.get('name') || 'Unnamed',
        emoji: '👤',
        category: $('#regCategory')?.value || fd.get('category') || '',
        location: $('#regLocation')?.value || fd.get('location') || '',
        price: Number($('#regExperience')?.value || 0) * 100, // heuristic
        exp: Number($('#regExperience')?.value || 0),
        rating: 4.0,
        jobs: 0,
        skills: ($('#regSkills')?.value || fd.get('skills') || '').split(',').map(s => s.trim()).filter(Boolean),
        phone: $('#regPhone')?.value || fd.get('phone') || ''
      };

      // POST create provider
      const provRes = await fetch('/api/providers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(providerObj)
      });
      const provBody = await safeJSON(provRes);
      if (!provRes.ok) {
        // app was saved; provider creation failed
        console.warn('Provider create failed', provBody);
        showToast('Application saved but creating provider failed', 'error');
        return;
      }

      showToast('Application submitted and provider created', 'success');
      form.reset();
      // re-render providers & locations
      await renderProvidersGrid();
      await populateLocationsFromProviders();
    } catch (err) {
      console.error('submitApplication error', err);
      showToast(err.message || 'Submission failed', 'error');
    }
  }

  /* ----------------- Event delegation for providers grid (book/details) ----------------- */
  function attachProvidersDelegation() {
    const grid = $('#providersGrid');
    if (!grid) return;
    grid.addEventListener('click', async (e) => {
      const btn = e.target.closest('button, a');
      if (!btn) return;
      const action = btn.dataset.action;
      if (action === 'book') {
        const id = Number(btn.dataset.id);
        // fetch provider details for selected id (optional)
        try {
          const res = await fetch(`/api/providers/${id}`);
          if (res.ok) {
            const p = await res.json();
            openBookingModal(p);
          } else {
            const body = await safeJSON(res);
            throw new Error(body.error || 'Could not get provider');
          }
        } catch (err) {
          console.error(err);
          showToast(err.message || 'Unable to open booking', 'error');
        }
      } else if (action === 'details') {
        const id = Number(btn.dataset.id);
        try {
          const res = await fetch(`/api/providers/${id}`);
          const body = await safeJSON(res);
          if (!res.ok) throw new Error(body.error || 'Failed to load details');
          const p = body;
          alert(`${p.name} • ${p.category}\nLocation: ${p.location}\nExperience: ${p.exp} years\nRating: ${p.rating} (${p.jobs} jobs)\nPricing: ${p.price}\nSkills: ${(p.skills||[]).join(', ')}`);
        } catch (err) {
          console.error(err);
          showToast(err.message || 'Failed to load details', 'error');
        }
      }
    });
  }

  /* ----------------- Misc helpers ----------------- */
  function setMinDateInputs() {
    const t = new Date();
    const yyyy = t.getFullYear();
    const mm = String(t.getMonth() + 1).padStart(2, '0');
    const dd = String(t.getDate()).padStart(2, '0');
    const today = `${yyyy}-${mm}-${dd}`;
    $('#helpDate')?.setAttribute('min', today);
    $('#bookingDate')?.setAttribute('min', today);
  }

  /* ----------------- Wire up forms & controls ----------------- */
  function wireControls() {
    // Help form (book via coordinator) - this previously saved to localStorage.
    $('#helpForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const form = e.currentTarget;
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      // Convert to object and POST to bookings endpoint as general request
      const data = {
        name: $('#helpName')?.value,
        phone: $('#helpPhone')?.value,
        email: $('#helpEmail')?.value,
        service: $('#helpService')?.value,
        date: $('#helpDate')?.value,
        time: $('#helpTime')?.value,
        address: $('#helpAddress')?.value,
        notes: $('#helpNotes')?.value
      };
      try {
        const res = await fetch('/api/bookings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        const body = await safeJSON(res);
        if (!res.ok) throw new Error(body.error || 'Request failed');
        showToast('We will connect you soon', 'success');
        form.reset();
      } catch (err) {
        console.error(err);
        showToast(err.message || 'Submission failed', 'error');
      }
    });

    // Register (provider) form
    $('#registerForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      submitApplicationAndAddProvider(e.currentTarget);
    });

    // Booking form
    $('#bookingForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      submitBooking(e.currentTarget);
    });

    // Cancel / close modal buttons
    $('#bookingClose')?.addEventListener('click', closeBookingModal);
    $('#bookingCancel')?.addEventListener('click', closeBookingModal);
    // close when clicking backdrop
    $('#bookingModal')?.addEventListener('click', (e) => {
      if (e.target === $('#bookingModal')) closeBookingModal();
    });

    // Provider filters
    $('#provSearch')?.addEventListener('input', debounce(applyProvFilters, 250));
    $('#provCategory')?.addEventListener('change', applyProvFilters);
    $('#provLocation')?.addEventListener('change', applyProvFilters);
    $('#provSort')?.addEventListener('change', applyProvFilters);
    $('#resetProv')?.addEventListener('click', () => {
      if ($('#provSearch')) $('#provSearch').value = '';
      if ($('#provCategory')) $('#provCategory').value = '';
      if ($('#provLocation')) $('#provLocation').value = '';
      if ($('#provSort')) $('#provSort').value = 'rating_desc';
      renderProvidersGrid();
    });
    $('#quickBook')?.addEventListener('click', async () => {
      // open booking modal for top-rated provider
      try {
        const list = await fetchProviders({ sort: 'rating_desc' });
        if (list && list.length) openBookingModal(list[0]);
      } catch (err) { /* ignore */ }
    });

    // quick nav from services
    document.addEventListener('click', (e) => {
      if (e.target.matches('[data-route="providers"][data-cat]')) {
        const id = e.target.getAttribute('data-cat');
        setTimeout(() => { $('#provCategory').value = id; applyProvFilters(); }, 0);
      }
    });
  }

  function fillSelectOptions() {
  const helpS = $('#helpService');
  if (helpS) {
    helpS.innerHTML = '<option value="" disabled selected>Select a service</option>'
      + categories.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
  }
  const rc = $('#regCategory');
  if (rc) {
    rc.innerHTML = '<option value="" disabled selected>Select a primary service</option>'
      + categories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  }
}

  /* ----------------- Init sequence ----------------- */
  async function init() {
    try {
      initTheme();
      initMobileNav();
      renderServicePills();
      renderServicesGrid();
      renderHomeCategories();
      initProviderFilters();
      attachProvidersDelegation();
      wireControls();
      setMinDateInputs();
      fillSelectOptions();

      // initial providers render and populate locations
      await renderProvidersGrid();
      await populateLocationsFromProviders();

      // navigate to current hash (or home)
      navigate(location.hash);
    } catch (err) {
      console.error('Initialization error', err);
      showToast('Initialization failed', 'error');
    }
  }

  // run on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
