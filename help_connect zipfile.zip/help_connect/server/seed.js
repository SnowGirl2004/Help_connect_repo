const mongoose = require("mongoose");
const Provider = require("./models/Provider");
const providers = require("./data/providers");

const MONGO = process.env.MONGO_URI || "mongodb://localhost:27017/helpconnect";

async function seed() {
  await mongoose.connect(MONGO);
  console.log("Connected to MongoDB for seeding");
  // Optional: clear existing
  await Provider.deleteMany({});
  console.log("Cleared existing providers");
  // Insert (ensure providers is an array with unique `id` values)
  await Provider.insertMany(providers);
  console.log("Inserted providers:", providers.length);
  process.exit(0);
}

seed().catch(err => {
  console.error(err);
  process.exit(1);
});