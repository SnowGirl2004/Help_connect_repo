
require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

const providersRouter = require("./routes/providers");
const bookingsRouter = require("./routes/bookings");
const applicationsRouter = require("./routes/applications");

const app = express();
app.use(express.static("public"));

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads"))); // serve uploaded files

// routes
app.use("/api/providers", providersRouter);
app.use("/api/bookings", bookingsRouter);
app.use("/api/applications", applicationsRouter);

// health
app.get("/api/health", (req,res)=> res.json({ok:true, env: process.env.NODE_ENV || "dev"}));

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || "mongodb://localhost:27017/helpconnect";

mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> {
    console.log("MongoDB connected");
    app.listen(PORT, ()=> console.log(`Server listening on port ${PORT}`));
  })
  .catch(err => {
    console.error("MongoDB connection error:", err.message);
    process.exit(1);
  });

