const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const BookingSchema = new Schema({
  providerId: { type: Schema.Types.Mixed, required: true },
  providerName: String,
  service: String,
  name: { type: String, required: true },
  phone: String,
  date: String,
  time: String,
  address: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Booking", BookingSchema);