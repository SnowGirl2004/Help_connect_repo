const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ApplicationSchema = new Schema({
  name: String,
  phone: String,
  email: String,
  category: String,
  location: String,
  experience: Number,
  skills: String,
  hasAadhaar: Boolean,
  bankName: String,
  account: String,
  ifsc: String,
  upi: String,
  aadhaarFile: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Application", ApplicationSchema);