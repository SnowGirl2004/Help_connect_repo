const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ProviderSchema = new Schema({
  id: { type: Number, index: true, unique: true },
  name: { type: String, required: true },
  emoji: String,
  category: String,
  location: String,
  price: Number,
  exp: Number,
  rating: Number,
  jobs: Number,
  skills: [String],
  phone: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Provider", ProviderSchema);